create function update_applicant_count() returns trigger
    language plpgsql
as
$$
begin
    update jobs
    set applicant_count = (select count(*) from applicants where job_id = NEW.id)
    where id = NEW.id;
    
    return NEW;
end;
$$;

alter function update_applicant_count() owner to postgres;

grant execute on function update_applicant_count() to anon;

grant execute on function update_applicant_count() to authenticated;

grant execute on function update_applicant_count() to service_role;

